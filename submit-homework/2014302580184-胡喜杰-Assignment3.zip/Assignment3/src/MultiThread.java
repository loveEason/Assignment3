
import java.sql.Statement;


//多线程爬取所有教师的信息
public class MultiThread implements Runnable{
    private int teachersCounts = 0;
    private static String[] teachersURL;
    private static String[] teachersName;
    private static String[] teachersResearchField;
    private int i;
    private Statement stmt;

    MultiThread(int teachersCounts,String[] teachersURL,String[] teachersName,String[] teachersResearchField,Statement stmt,int i) {
        this.teachersCounts = teachersCounts;
        this.teachersURL = teachersURL;
        this.teachersName = teachersName;
        this.teachersResearchField = teachersResearchField;
        this.stmt = stmt;
        this.i = i;
    }

    public void run() {
        while (true) {
            synchronized ("") {
                if (i < teachersCounts) {
                    try {
                        Thread.sleep(10);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    try {
                        WriteToMySQL.TeachersInfo(teachersURL, teachersName, teachersResearchField, stmt, i);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    i+=2;
                }else break;
            }
        }
    }


/*    public synchronized void Crawl(String[] teachersURL,String[] teachersName,String[] teachersResearchField,Statement stmt,int i) {
        if(i<teachersCounts) {
            try{
                Thread.sleep(1);
            }catch (Exception e){
                e.printStackTrace();
            }
            try {
                WriteToMySQL.TeachersInfo(teachersURL, teachersName, teachersResearchField,stmt,i);
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void run() {
        while (true) {
            if(i<teachersCounts) {
                Crawl(teachersURL,teachersName,teachersResearchField,stmt,i);
                i+=2;
            }else break;
        }
    }*/

}
