import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 从任意某大学网站一串教师列表中找到所有教师主页，
 * 并从爬取这些主页中所有的教师个人信息。
 * 爬取后请将这些信息存入到数据库中。
 * 教师个人信息要包括： 姓名，邮箱（ 电话 ），研究领域，简介等。
 * 要求写出单线程爬取与多单线程爬取两种不同的爬取方式的示例,并记录两种爬取方式各自的运行时间。
 *
 * 学号：2014302580184
 * 姓名：胡喜杰
 * 时间：2015.11.3-2015.11.7
 */
public class Assignment3_2014302580184 {
    private String mainURL = "http://cs.whu.edu.cn/plus/list.php?tid=36";
    private String partURL = "http://cs.whu.edu.cn/plus/";
    private String fmainURLNamehtml = "AllTeachersMainPage.html";
    private String fmainURLNametxt = "AllTeachersURL.txt";
    private static String[] teachersURL;
    private static String[] teachersName;
    private static String[] teachersResearchField;
    private static int teachersCounts = 0;
    public static long startTime;
    private long endTime;

    public static void main(String[] args) {
        Assignment3_2014302580184 test = new Assignment3_2014302580184();
        try {
            test.TeachersURL();
            test.JSoupGetURLs();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //加载JDBC驱动程序
        try {
            Class.forName("com.mysql.jdbc.Driver"); //动态加载mysql驱动
            System.out.println("成功加载MySQL驱动程序");
        } catch (ClassNotFoundException e) {
            System.out.println("找不到驱动程序类。加载驱动失败");
            e.printStackTrace();
        }

        //提供JDBC连接的URL
        String url = "jdbc:mysql://localhost:3306/teacherinfo_db?" +
                "user=root&password&useUnicode=true&characterEncoding=GBK";
        //创建数据库连接
        Connection con = null;
        try {
            con = DriverManager.getConnection(url);
            System.out.println("数据库连接成功");
        } catch (SQLException e) {
            System.out.println("数据库连接失败");
            e.printStackTrace();
        }

        String sql;
        Statement stmt = null;
        try {
            stmt = con.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //创建数据表
        sql = "create table teacher(" +
                "id int unsigned not null auto_increment primary key," +
                "name char(8) not null," +
                "phone char(15) not null," +
                "email char(30) not null," +
                "research text not null," +
                "introduction text not null)";
        try {
            stmt.executeUpdate("drop table if exists teacher");
            int result = stmt.executeUpdate(sql);   //返回一个受影响的行数，如果返回-1就没有成功
            if (result != -1) {
                System.out.println("创建数据表成功");
                test.startTime = System.currentTimeMillis();

/*                //单线程爬取
                for(int i=0;i<teachersCounts;i++) {
                    WriteToMySQL.TeachersInfo(teachersURL, teachersName, teachersResearchField,stmt,i);
                }
                System.out.println("单线程需要时间："+String.valueOf(System.currentTimeMillis()-test.startTime));*/

                //多线程爬取
                ExecutorService executorService = Executors.newCachedThreadPool();
                for(int i=0;i<2;i++) {
                    executorService.execute(new MultiThread(teachersCounts, teachersURL, teachersName, teachersResearchField, stmt,i));
                }
                executorService.shutdown();
                while (!executorService.isTerminated()) {
                }
                System.out.println("多线程需要时间："+String.valueOf(System.currentTimeMillis()-test.startTime));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        //关闭JDBC对象
        try {
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    //爬虫存有教师个人页面的主页面
    public void TeachersURL() throws Exception {
        HttpRequest request = HttpRequest.get(mainURL);
        File fName = new File(fmainURLNamehtml);
        if(!fName.exists()) request.receive(fName);
    }

    //使用JSoup对所爬取的主页面html代码进行解析，获取所有教师的个人主页url，存取在文件中
    public void JSoupGetURLs() throws Exception{
        //创建输出文件
        File output = new File(fmainURLNametxt);
        FileWriter fw = new FileWriter(output);
        BufferedWriter bfw = new BufferedWriter(fw);

        //从文件中加载html文档
        File input = new File(fmainURLNamehtml);
        Document doc = Jsoup.parse(input, "UTF-8");

        //解析并提取url元素
        Elements link = doc.select("a[href*=\"view.php?aid\"]");
        Pattern urlPattern = Pattern.compile("view.+php.+aid.+\\d+");
        Pattern namePattern = Pattern.compile("[\u4E00-\u9FA5]+");
        Elements researchFiled = doc.select("span.job_research");

        int k = 0;
        while(k<link.size()) {
            Matcher nameMatcher = namePattern.matcher(link.get(k).toString());
            Matcher urlMatcher = urlPattern.matcher(link.get(k).toString());
            while(nameMatcher.find()&&urlMatcher.find()) {
                bfw.write(partURL+urlMatcher.group());
                bfw.newLine();
                teachersCounts++;
            }
            k++;
        }

        //解析并提取教师名字、个人主页url、研究领域
        teachersName = new String[teachersCounts];
        teachersURL = new String[teachersCounts];
        teachersResearchField = new String[teachersCounts];
        int i = 0;
        int j = 0;
        while(i<link.size()) {
            Element researchfield = researchFiled.get(i);
            Matcher nameMatcher = namePattern.matcher(link.get(i).toString());
            Matcher urlMatcher = urlPattern.matcher(link.get(i).toString());
            while(nameMatcher.find()&&urlMatcher.find()) {
                teachersName[j] = nameMatcher.group().toString();
                teachersURL[j] = partURL+urlMatcher.group().toString();
                teachersResearchField[j] = researchfield.text().toString();
                j++;
            }
            i++;
        }
        bfw.close();
        fw.close();
    }

}

