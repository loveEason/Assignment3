import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Administrator on 2015/11/7.
 */
public class WriteToMySQL {
    public static void TeachersInfo(String[] teachersURL, String[] teachersName, String[] teachersResearchField, Statement stmt,int i) throws Exception {
        int judge = 0;
        String sql;//爬取
        HttpRequest request = HttpRequest.get(teachersURL[i]);
        File fName = new File("teachersInfo/" + teachersName[i] + ".html");
        if (!fName.exists()) request.receive(fName);

        //解析
        Document doc = Jsoup.parse(fName, "UTF-8");
        Elements content = doc.select("ul.about_info");

        //姓名
        String getName = teachersName[i];

        //联系方式
        Pattern phonePattern = Pattern.compile("\\d{11}");
        Pattern emailPattern = Pattern.compile("\\w+@\\w+.\\w+.\\w+");
        Matcher phoneMatcher = phonePattern.matcher(content.toString());
        Matcher emailMatcher = emailPattern.matcher(content.toString());
        String getPhone = null;
        String getEmail = null;
        while (phoneMatcher.find()) {
            getPhone = phoneMatcher.group().toString();
            judge = 1;
        }
        if (judge == 0) getPhone = "null";
        else judge = 0;
        while (emailMatcher.find()) {
            getEmail = emailMatcher.group().toString();
            judge = 1;
        }
        if (judge == 0) getEmail = "null";
        else judge = 0;
        //研究领域
        String getResearch = null;
        if (!teachersResearchField[i].equals("")) {
            getResearch = teachersResearchField[i];
        } else getResearch = "null";

        //个人简介
        Elements content2 = doc.select("div.info_list p");
        Element controduction = content2.get(0);
        Element controduction2 = content2.get(1);
        String getIntroduction = null;
        if (!controduction.text().equals("")) {
            getIntroduction = controduction.text().toString();
        } else if (!controduction2.text().equals("")) {
            getIntroduction = controduction2.text().toString();
        } else getIntroduction = "null";

        //向数据表中插入数据
        sql = "insert into teacher values(" + "NULL" + "," + "'" + getName + "'" + "," + "'" + getPhone + "'" + "," + "'" + getEmail + "'" + "," + "'" + getResearch + "'" + "," + "'" + getIntroduction + "'" + ")";
        System.out.println(sql);
        stmt.executeUpdate(sql);
    }
}
